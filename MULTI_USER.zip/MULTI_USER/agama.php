<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device
    <title>Document</title>
</head>
<body>
    <label for=" agama</label><br>
    <input type=" radio>