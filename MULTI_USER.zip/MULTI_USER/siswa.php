<?php

session_start();
include "koneksi.php";

if (issert($_POST['tambah']));
$NIS = $_POST['NIS'];
$NAME = $_POST['NAME'];
$tempat_lahir = $_POST['tempat_lahir'];
$tanggal_lahir = $_POST['tanggal_lahir'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$agama = $_POST['agama'];
$ayah = $_POST['ayah'];
$ibu = $_POST['ibu'];
$pekerjaan_ayah = $_POST['pekerjaan_ayah'];
$pekerjaan_ayah = $_POST['pekerjaan_ibu'];
$alamat = $_POST['alamat'];

$query = mysql_query($koneksi, "INSERT INTO siswa(NIS,Nama, tempat_lahir, tanggal_lahir, jenis kelamin, agama, ayah, ibu, pekerjaan_ayah, pekerjaan_ibu, alamat");
values ("$NIS','$nama,'$tempat_lahir','$tanggal_lahir','jenis kelamin','agama','ayah','ibu','pekerjaan_ibu','alamat");

if($query){
    echo <script> alert("Selamat Berhasil memasukan data")</script>';
} else {
    echo <script> alert("gagal memasukan data")</script>';
  }
}



