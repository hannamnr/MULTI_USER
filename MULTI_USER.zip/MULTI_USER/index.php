<?php


session_start();
include 'koneksi_login';
if(inssert($_POST['USERE'])){
   header('Location.href="login.php");
}

    