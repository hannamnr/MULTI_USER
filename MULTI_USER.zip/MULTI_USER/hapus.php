<a href="hapus data_siswa.php?id_siswa= <php echo $data['nis]; ?>">Hapus</a>
<?php 
include 'koneksi.php'
$nis = $_GET['nis'];
$hapus = mysqli_query($connection, "DELETE FROMM siswa WHERE nis=$NIS");
if ($hapus) {
    
}