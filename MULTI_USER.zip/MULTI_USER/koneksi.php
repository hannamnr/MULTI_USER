<?php

$koneksi = mysqli_connect("localhost", "root", "user_level") or die("Database Gagal");
