<?php 

session_start();
include 'koneksi.php';

if (isset($_SESSION["login"])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = mysqli_query($koneksi, "SELECT * FROM admin WHERE username = '$username' AD password = '$password");

    if(mysqli_num_rows($query) > 0) {
       echo'<script>alert("Selamat Anda Berhasil Login");
       location.href="index.php";</script>
    } else {
        echo <'script> alert("Anda Gagal Login");</script>
  }
}


?>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Form Login</title>
</head>
<body>
    <div class="form-container>
          <h2>Silahkan Login</h2>
          <div class="form-input>
          <form method="post>
          <div class="input>
          <input type="text" placeholder="Masukan Username" name="username" required>
    </div>
          <div class="input">
          <input type="text" placeholder="Masukan password" name="password" required>
    </div> 
    <div>
          <buttom type="submit" class="buttom"> 
          <
            


           





   
    
    

